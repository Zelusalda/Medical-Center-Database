# Medical-Center-Database
Database for medical center in SQL
